@include("header")

@extends("master")

@section("navbar")

@section("content")
<div class="container mt-5">
<div class="row">
    <div class="col-md-12">
        <table class="table">
            <thead class=" bg-Secondary text-light">
                <tr>
                <th scope="col">No</th>
                <th scope="col">Judul Komik</th>
                <th scope="col">Genre</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                @foreach($komiklist as $komik)
                        <td>{{ $komik->id }}</td>
                        <td>{{ $komik->nama_komik }}</td>
                        <td>{{ $komik->genre }}</td>
                </tr>
                @endforeach

            </tbody>
        </table>
    </div>

</div>

</div>
@endsection

@section("footer")
