<?php echo $__env->make("header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection("navbar"); ?>

<?php $__env->startSection("content"); ?>
<div class="container mt-5">
<div class="row">
    <div class="col-md-12">
        <table class="table">
            <thead class=" bg-Secondary text-light">
                <tr>
                <th scope="col">No</th>
                <th scope="col">Judul Komik</th>
                <th scope="col">Genre</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <?php $__currentLoopData = $komiklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($komik->id); ?></td>
                        <td><?php echo e($komik->nama_komik); ?></td>
                        <td><?php echo e($komik->genre); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("footer"); ?>

<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas\Semester 7\Webprog\Lec\GSLC\GSLC1\resources\views/home.blade.php ENDPATH**/ ?>