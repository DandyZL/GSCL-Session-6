<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KomikController extends Controller
{
    public function index()
    {
        $komiklist = DB::table('komiklist')->get();
        return view('home', compact('komiklist'));
    }
}
